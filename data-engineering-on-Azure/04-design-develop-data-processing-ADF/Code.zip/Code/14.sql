-- Lab - Processing JSON Arrays

CREATE TABLE [Customercourse]
(
    [CustomerID] int,
    [CustomerName] varchar(200),
    [Registered] BIT,
    [Courses] varchar(200)
)