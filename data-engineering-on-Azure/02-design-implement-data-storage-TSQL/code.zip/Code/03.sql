-- Lab - T-SQL - ORDER BY clause

-- The ORDER BY keyword is used to sort the result-set in ascending or descending order.
-- By default the records are sorted in ascending order

SELECT * FROM SalesLT.Product ORDER BY Listprice

SELECT * FROM SalesLT.Product ORDER BY Listprice DESC