-- Lab - T-SQL - SELECT clause
-- THE SELECT Statement is used to project what columns you want to see in the results

SELECT * FROM SalesLT.Product

SELECT COUNT(*) FROM SalesLT.Product

SELECT ProductID, Name, ProductNumber FROM SalesLT.Product