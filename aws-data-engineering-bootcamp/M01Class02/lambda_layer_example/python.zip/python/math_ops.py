def square(n):
	return n**2

def sum(x,y):
	return x+y
