def double_string(n):
    return n*2
